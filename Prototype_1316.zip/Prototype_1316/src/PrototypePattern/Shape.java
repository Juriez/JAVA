package PrototypePattern;

import java.util.Objects;

public abstract class Shape {
	public int x;
	public int y;
	public String color;
	
	public Font font;
	public Shape() {
		
	}
	public Shape(Shape next) {
		if(next != null) {
			this.x = next.x;
			this.y = next.y;
			this.color = next.color;
			this.font =  next.font.clone();
		}
	}
	
public abstract Shape clone();
	
	@Override
	public boolean equals(Object object2) {
		if(!(object2 instanceof Shape))
			return false;
		Shape shape = (Shape) object2;
		return shape.x == x && shape.y == y && Objects.equals(shape.color, color);
	}
}
