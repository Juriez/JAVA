package PrototypePattern;

public class Rectangle extends Shape {
	public int hight;
	public int width;
	public Rectangle() {
		
	}
	public Rectangle(Rectangle next) {
		super(next);
		if(next != null) {
		this.hight = next.hight;
		this.width = next.width;
		}
	}

	@Override
	public Shape clone() {
		// TODO Auto-generated method stub
		return new Rectangle(this);
	}
	
	@Override
	public boolean equals(Object object2) {
		if(!(object2 instanceof Rectangle) || !super.equals(object2))
			return false;
			Rectangle shape = (Rectangle) object2;
			return shape.width == width && shape.hight == hight;
	}
	

}
