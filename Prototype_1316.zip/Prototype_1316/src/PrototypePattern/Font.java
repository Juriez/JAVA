package PrototypePattern;

public class Font {
	    public int font_size;
	    public Font(int n) {
	    	this.font_size = n;
	    }

	    public Font(Font next1) {
	    	if(next1!=null) {
	    		this.font_size= next1.font_size;
	    
	    	}
	    }
	    
	    @Override
		public Font clone() {
			// TODO Auto-generated method stub
			return new Font(this);
		}
		

	    @Override
	    public String toString() {
	        return "Font{" +
	                "font_size=" + font_size +
	                '}';
	    }
	}

	

