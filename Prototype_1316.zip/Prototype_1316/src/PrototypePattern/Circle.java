package PrototypePattern;

public class Circle extends Shape {
	public int radious;
	public Circle() {
		
	}
	public Circle(Circle next) {
		super(next);
		if(next != null)
		this.radious = next.radious;
	}

	@Override
	public Shape clone() {
		// TODO Auto-generated method stub
		return new Circle(this);
	}
	
	@Override
	public boolean equals(Object object2) {
		if(!(object2 instanceof Circle ) || !super.equals(object2))
		return false;
		Circle shape = (Circle) object2;
		return shape.radious == radious;
		
		
	}

}
