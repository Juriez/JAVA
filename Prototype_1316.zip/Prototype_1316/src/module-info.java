/**
 * 
 */
/**
 * 
 */
module PrototypePattern {
}