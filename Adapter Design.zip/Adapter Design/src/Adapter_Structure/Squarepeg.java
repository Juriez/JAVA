package Adapter_Structure;

public class Squarepeg {
	public double width;
	public Squarepeg(double width) {
		this.width = width;
	}
	
	public double getWidth() {
		return width;
	}
	
	public double getRadious() {
		double result;
		result = (this.width * this.width);
		return result;
	}

	

}
