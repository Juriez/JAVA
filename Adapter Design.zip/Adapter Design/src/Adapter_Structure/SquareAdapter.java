package Adapter_Structure;

public class SquareAdapter extends Roundpeg {
	public Squarepeg peg;
	public SquareAdapter(Squarepeg peg) {
		this.peg = peg;
	}
	@Override
	public double getRadious() {
		double result;
		result = (Math.sqrt(Math.pow((peg.getWidth() / 2), 2) * 2));
		return result;
	}
	

}
