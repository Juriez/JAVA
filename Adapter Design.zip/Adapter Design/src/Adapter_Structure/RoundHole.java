package Adapter_Structure;

public class RoundHole {
	public double radious;
	
	public RoundHole(double radious) {
		this.radious = radious;
	}
	public double getRadious() {
		return radious;
	}
	
	public boolean fits(Roundpeg peg) {
		boolean result;
		result = (this.getRadious() >= peg.getRadious());
		return result;
	}

}
