package Adapter_Structure;

public class Roundpeg {
	public double radious;
	public Roundpeg() {
		
	}
	
	public Roundpeg(double radious) {
		this.radious = radious;
	}
	
	public double getRadious() {
		return radious;
	}

}
