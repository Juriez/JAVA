package BuilderDesign;

public enum Cartype {
	CITY_CAR, SPORTS_CAR, SUV

}
