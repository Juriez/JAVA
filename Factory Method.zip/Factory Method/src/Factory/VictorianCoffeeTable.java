package Factory;

public class VictorianCoffeeTable implements CoffeeTable {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.err.println("Victorian Coffee table has two handles");
		
	}

	@Override
	public void coffeeSet() {
		// TODO Auto-generated method stub
		System.err.println(" There is a coffee set on that Victorian coffee table.");
	}

}
