package Factory;

public class ArtDecoCoffeeTable implements CoffeeTable {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.err.println("ArtDeco coffee table has two handle.");
		
	}

	@Override
	public void coffeeSet() {
		// TODO Auto-generated method stub\
		System.err.println("There is coffee set on that ArtDeco coffee table.");
		
	}

}
