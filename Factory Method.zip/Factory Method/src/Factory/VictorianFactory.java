package Factory;

public class VictorianFactory implements Factory {

	@Override
	public Chair makeChair() {
		// TODO Auto-generated method stub
		System.err.println("Factory make victorian chair.");
		return new VictorianChair();
		
	}

	@Override
	public Sofa makeSofa() {
		// TODO Auto-generated method stub
		System.err.println("Factory make victorian sofa.");
		return new VictorianSofa();
		
	}

	@Override
	public CoffeeTable makeCoffeeTable() {
		// TODO Auto-generated method stub
		System.err.println("Factory make victorian coffee table.");
		return new VictorianCoffeeTable();
		
	}

}
