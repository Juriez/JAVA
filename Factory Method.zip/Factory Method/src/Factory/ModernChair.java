package Factory;

public class ModernChair implements Chair {

	@Override
	public void chairLeg() {
		// TODO Auto-generated method stub
		System.err.println("Modern chair has four legs.");
		
	}

	@Override
	public void sitChair() {
		// TODO Auto-generated method stub
	  System.err.println("Sit on modern chair");
		
	}

}
