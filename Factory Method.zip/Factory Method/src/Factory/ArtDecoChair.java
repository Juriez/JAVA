package Factory;

public class ArtDecoChair implements Chair {

	@Override
	public void chairLeg() {
		System.err.println("ArtDecoChair has four legs");
		
	}

	@Override
	public void sitChair() {
		// TODO Auto-generated method stub
		System.err.println("Sit on the ArtDeco Chair");
	}
	

}
