package Factory;

public interface Chair {
	void chairLeg();
	void sitChair();
}
