package Factory;

public interface CoffeeTable {
	void handle();
	void coffeeSet();
}
