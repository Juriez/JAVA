package Factory;

public class ModernFactory implements Factory {

	@Override
	public Chair makeChair() {
		// TODO Auto-generated method stub
		System.err.println("Factory make Modern chair.");
		return new ModernChair();
		
	}

	@Override
	public Sofa makeSofa() {
		// TODO Auto-generated method stub
		System.err.println("Factory make modern sofa.");
		return new ModernSofa();
		
	}

	@Override
	public CoffeeTable makeCoffeeTable() {
		// TODO Auto-generated method stub
		System.err.println("Factory make modern coffee table.");
		return new ModernCoffeeTable();
		
	}

}
