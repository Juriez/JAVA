package Factory;

public interface Factory {
	Chair makeChair();
	Sofa makeSofa();
	CoffeeTable makeCoffeeTable();

}
