package Factory;

public class VictorianSofa implements Sofa {

	@Override
	public void sofaLeg() {
		// TODO Auto-generated method stub
		System.err.println("Victorian sofa has four legs.");
		
	}

	@Override
	public void sitSofa() {
		// TODO Auto-generated method stub
		System.err.println("Sit on that Victorian sofa");
		
	}

}
