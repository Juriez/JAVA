package Factory;

public class VictorianChair implements Chair {

	@Override
	public void chairLeg() {
		// TODO Auto-generated method stub
		System.err.println("Victorian chair has four legs");
		
	}

	@Override
	public void sitChair() {
		// TODO Auto-generated method stub
		System.err.println("Sit on that Victorian Chair");
		
	}

}
