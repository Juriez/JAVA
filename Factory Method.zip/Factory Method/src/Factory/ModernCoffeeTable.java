package Factory;

public class ModernCoffeeTable implements CoffeeTable {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.err.println("Modern Coffee Table has no handles.");
	}

	@Override
	public void coffeeSet() {
		// TODO Auto-generated method stub
		System.err.println("There are two coffee set on that modern coffee table");
		
	}

}
