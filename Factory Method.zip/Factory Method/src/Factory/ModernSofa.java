package Factory;

public class ModernSofa implements Sofa {

	@Override
	public void sofaLeg() {
		// TODO Auto-generated method stub
		System.err.println("Modern Sofa has no legs");
		
	}

	@Override
	public void sitSofa() {
		// TODO Auto-generated method stub
		System.err.println("Please sit on that Modern sofa");
		
	}

}
