package Factory;

public interface Sofa {
	void sofaLeg();
	void sitSofa();

}
