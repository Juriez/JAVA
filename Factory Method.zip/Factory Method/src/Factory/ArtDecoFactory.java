package Factory;

public class ArtDecoFactory implements Factory {

	@Override
	public Chair makeChair() {
		// TODO Auto-generated method stub
		//Chair art = new Chair();
		System.err.println("Factory make ArtDeco Chair.");
		return new ArtDecoChair();
		
	}

	@Override
	public Sofa makeSofa() {
		// TODO Auto-generated method stub
		System.err.println("Factory make ArtDeco Sofa.");
		return new ArtDecoSofa();
		
	}

	@Override
	public CoffeeTable makeCoffeeTable() {
		// TODO Auto-generated method stub
		System.err.println("Factory make ArtDeco Coffee table.");
		return new ArtDecoCoffeeTable();
		
	}

}
