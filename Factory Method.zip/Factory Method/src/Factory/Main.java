package Factory;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Factory fact = new ArtDecoFactory();
		Factory fact2 = new VictorianFactory();
		Factory fact3 = new ModernFactory();
		Chair chair = fact.makeChair();
		Chair chair2 = fact2.makeChair();
		Chair chair3 = fact3.makeChair();
		Sofa sofa = fact.makeSofa();
		Sofa sofa2 = fact2.makeSofa();
		Sofa sofa3 = fact3.makeSofa();
		CoffeeTable ct = fact.makeCoffeeTable();
		CoffeeTable ct2 = fact2.makeCoffeeTable();
		CoffeeTable ct3 = fact3.makeCoffeeTable();
		chair.chairLeg();
		chair.sitChair();
		chair2.chairLeg();
		chair2.sitChair();
		chair3.chairLeg();
		chair3.sitChair();
		sofa.sofaLeg();
		sofa.sitSofa();
		sofa2.sofaLeg();
		sofa2.sitSofa();
		sofa3.sofaLeg();
		sofa3.sitSofa();
		ct.coffeeSet();
		ct.handle();
		ct2.coffeeSet();
		ct2.handle();
		ct3.coffeeSet();
		ct3.handle();
		

	}

}
