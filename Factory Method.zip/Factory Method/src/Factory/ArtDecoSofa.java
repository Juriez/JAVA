package Factory;

public class ArtDecoSofa implements Sofa {

	@Override
	public void sofaLeg() {
		// TODO Auto-generated method stub
		System.err.println("ArtDeco Sofa has four legs.");
		
	}

	@Override
	public void sitSofa() {
		// TODO Auto-generated method stub
		System.err.println("Sit on that Artdeco sofa.");
	}

}
