package Singleton_exmple;

public class DemoSingletonThread2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.err.println("If you see the same value, then singleton was reused.");
		System.err.println("If you see different values, then 2 singletons were created.");	
		System.err.println("Result : ");
		Thread threadfoo = new Thread(new Threadfoo());
		Thread threadbar = new Thread(new Threadbar());
		threadfoo.start();
		threadbar.start();	
	}

	
	static class Threadfoo implements Runnable {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Singleton singleton = Singleton.getInstance("FOO");
            System.err.println(singleton.value);
			
	}
	}
	static class Threadbar implements Runnable {
		@Override
		public void run() {
			// TODO Auto-generated method stub
			Singleton singleton = Singleton.getInstance("BAR");
            System.err.println(singleton.value);
		}
	}

	
	
}


