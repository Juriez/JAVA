/**
 * 
 */
/**
 * 
 */
module Singleton {
}